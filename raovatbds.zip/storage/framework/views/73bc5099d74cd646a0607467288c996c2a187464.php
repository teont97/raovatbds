<?php $__env->startSection('title','Danh sách tất cả các tin vip '); ?>
<?php $__env->startSection('content'); ?>
    <!-- Sub banner start -->
<div class="sub-banner overview-bgi">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <h1>Danh sách tất cả các tin vip</h1>
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('gethome')); ?>">Tra ng Chủ</a></li>
                    <li class="active">Danh sách tất cả các tin vip</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- Properties section body start -->
<div class="properties-section content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12">
                <!-- Option bar start -->
                <div class="option-bar">
                    <div class="row">
                       <div class="col-lg-6 col-md-5 col-sm-5 col-xs-2">
                           <h4>
                                <span class="heading-icon">
                                    <i class="fa fa-th-large"></i>
                                </span>
                                <span class="hidden-xs">Properties Grid</span>
                            </h4>
                        </div>
                        <div class="col-lg-6 col-md-7 col-sm-7 col-xs-10 cod-pad">
                            <div class="sorting-options">
                                <select class="sorting">
                                   <option>New To Old</option>
                                   <option>Old To New</option>
                                   <option>Properties (High To Low)</option>
                                   <option>Properties (Low To High)</option>
                                </select>
                                <a href="properties-list-rightside.html" class="change-view-btn"><i class="fa fa-th-list"></i></a>
                                <a href="properties-grid-rightside.html" class="change-view-btn active-view-btn"><i class="fa fa-th-large"></i></a>
                           </div>
                       </div>
                    </div>
                </div>
                <!-- Option bar end -->
                <div class="clearfix"></div>
                <div class="row">
                    <?php $__currentLoopData = $data_vip; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iteam_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 wow fadeInUp delay-03s">
                        <!-- Property start -->
                        <div class="property">
                            <!-- Property img -->
                            <div class="property-img">
                                <?php 
                                    $data=$iteam_post->post_images->shift(); 
                                ?>
                                <div class="property-tag button alt featured">Hot</div>
                                <div class="property-tag button sale"><?php echo $iteam_post->hinhthuc['name'];; ?></div>
                                <div class="property-price"><?php echo $iteam_post->price; ?></div>
                                 
                                <img src="<?php echo asset('storage\app\public\upload\images/'.$data['images']); ?>" alt="fp" class="img-responsive">
                                <div class="property-overlay">
                                    <a href="<?php echo route('getproductdetail',$iteam_post->id); ?>" class="overlay-link">
                                        <i class="fa fa-link"></i>
                                    </a>
                                    <a class="overlay-link property-video" title="Lexus GS F">
                                        <i class="fa fa-video-camera"></i>
                                    </a>
                                    <div class="property-magnify-gallery">
                                        <a href="#" class="overlay-link">
                                            <i class="fa fa-expand"></i>
                                        </a>
                                        <a href="#" class="hidden"></a>
                                        <a href="#" class="hidden"></a>
                                    </div>
                                </div>
                            </div>
                            <!-- Property content -->
                            <div class="property-content">
                                <!-- title -->
                                <h1 class="title">
                                    <a href="<?php echo route('getproductdetail',$iteam_post->id); ?>"><?php echo $iteam_post->title; ?></a>
                                </h1>
                                <!-- Property address -->
                                <h3 class="property-address">
                                    <a href="properties-details.html">
                                        <i class="fa fa-map-marker"></i><?php echo $iteam_post->address; ?>

                                    </a>
                                </h3>
                                <!-- Facilities List -->
                                <ul class="facilities-list clearfix">
                                    <li>
                                        <i class="flaticon-square-layouting-with-black-square-in-east-area"></i>
                                        <span> Diện tích <?php echo e($iteam_post->area); ?> m2</span>
                                    </li>
                                    <li>
                                        <i class="glyphicon glyphicon-usd"></i>
                                        <span>Giá <?php echo e($iteam_post->price); ?> <?php echo e($iteam_post->Unit['name']); ?></span>
                                    </li>
                                </ul>
                                <!-- Property footer -->
                                <div class="property-footer">
                                    <span class="left">
                                        <a href="#"><i class="fa fa-user"></i><?php echo $iteam_post->User['name'];; ?></a>
                                    </span>
                                    <?php $datalh=$iteam_post->lienhe->shift(); ?>
                                    <span class="right">
                                        <i class="fa fa-phone" ></i><?php echo $datalh['sodienthoai']; ?>

                                    </span>
                                </div>
                            </div>
                        </div>
                        <!-- Property end -->
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Page navigation start -->
                <nav aria-label="Page navigation">
                    <?php echo e($data_vip->links()); ?>

                </nav>
                <!-- Page navigation end-->
            </div>
            <!-- sidebar right start -->
            <?php echo $__env->make('client.block.sidebar_post', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- sidebar right end -->
        </div>
    </div>
</div>
<!-- properties section end -->
<?php echo $__env->make('client.block.brands', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>