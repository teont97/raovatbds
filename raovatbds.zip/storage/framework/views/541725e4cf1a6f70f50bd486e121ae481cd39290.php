<div class="partners-block">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="carousel our-partners slide" id="ourPartners">
                    <div class="carousel-inner">
                        <div class="item active">
                            <div class="col-xs-12 col-sm-6 col-md-3 partner-box">
                                <a href="#">
                                    <img src="<?php echo asset('public/client/img/bussiness/01.png'); ?>" alt="partner" style="width:135px ; height:50px;" >
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3 partner-box">
                                <a href="#">
                                    <img src="<?php echo asset('public/client/img/bussiness/02.png'); ?>" alt="partner-2" style="width:135px; height:50px;">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3 partner-box">
                                <a href="#">
                                    <img src="<?php echo asset('public/client/img/bussiness/03.png'); ?>" alt="partner-3" style="width:135px ; height:50px;">
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3 partner-box">
                                <a href="#">
                                    <img src="<?php echo asset('public/client/img/bussiness/04.png'); ?>" alt="partner-4" style="width:135px ; height:50px;" >
                                </a>
                            </div>
                        </div>
                        <div class="item">
                            <div class="col-xs-12 col-sm-6 col-md-3 partner-box">
                                <a href="#">
                                    <img src="<?php echo asset('public/client/img/bussiness/06.png'); ?>" alt="partner-5" style="width:135px ; height:50px;">
                                </a>
                            </div>
                        </div>
                    </div>
                    <a class="left carousel-control" href="#ourPartners" data-slide="prev"><i class="fa fa-chevron-left icon-prev"></i></a>
                    <a class="right carousel-control" href="#ourPartners" data-slide="next"><i class="fa fa-chevron-right icon-next"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>