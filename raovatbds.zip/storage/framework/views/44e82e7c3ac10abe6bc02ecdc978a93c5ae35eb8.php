<?php $__env->startSection('title',$data_type['name']); ?>
<?php $__env->startSection('description',$data_type['name']); ?>
<?php $__env->startSection('content'); ?>
<!-- Banner start -->
<div class="blog-banner">
    <div class="container">
        <div class="breadcrumb-area mt-60">
        <h1><?php echo e($data_type['name']); ?></h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('gethome')); ?>">Trang chủ</a></li>
                <li class="active"><?php echo e($data_type['name']); ?></li>
            </ul>
        </div>
    </div>
</div>

<!-- Banner end -->
<!-- Blog body start -->
<div class="blog-body content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12">
                <div class="row">
                    <?php $__currentLoopData = $data_blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iteam_blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 col-md-6 col-sm-6 ">
                            <div class="thumbnail blog-box-2 clearfix">
                                <div class="blog-photo">
                                    <img src="<?php echo asset('public/admin/dist/img/'.$iteam_blog->images); ?>" alt="blog-1" class="img-responsive">
                                </div>
                                <!-- Detail -->
                                <div class="caption detail">
                                    <h4><a href="<?php echo URL::route('getblog.detail',$iteam_blog['id']); ?>"><?php echo $iteam_blog->title; ?></a></h4>
                                    <!-- paragraph -->
                                    <p><?php echo $iteam_blog->tomtat; ?></p>
                                    <div class="clearfix"></div>
                                    <!-- Btn -->
                                    <a href="<?php echo URL::route('getblog.detail',$iteam_blog['id']); ?>" class="read-more">Xem Chi Tiết </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <!-- Blog box end -->

                <!-- Page navigation start -->
                <nav aria-label="Page navigation">
                    <?php echo e($data_blog->links()); ?>

                </nav>
                <!-- Page navigation end -->
            </div>
            <!-- sidebar right start -->
            <?php echo $__env->make('client.block.sidebar_blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- sidebar right end -->
        </div>
    </div>
</div>
<!-- Blog body end -->
<?php echo $__env->make('client.block.brands', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>