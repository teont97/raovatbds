<?php $__env->startSection('title','Thông tin tài khoản'); ?>
<?php $__env->startSection('content'); ?>
<!-- Sub banner start -->
<div class="sub-banner overview-bgi">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <h1>Thông tin cá nhân </h1>
                <ul class="breadcrumbs">
                    <li><a href="<?php echo e(route('gethome')); ?>">Trang chủ </a></li>
                    <li class="active">Thông tin cá nhân</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- My profile start -->
<div class="content-area my-profile">
    <div class="container">
        <div class="row">
            <?php echo $__env->make('client.block.account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-lg-8 col-md-8 col-sm-12">
                <!-- My address start-->
                <div class="my-address">
                    <div class="main-title-2">
                        <h1><span>Cập Nhật Lại Thông Tin Cá Nhân </span> </h1>
                    </div>
                <form action="<?php echo e(route('personal.update.profile',Auth::user()->id)); ?>" method="POST">
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <div class="form-group">
                            <label>Họ Và Tên</label>
                            <input type="text" class="input-text" name="name" value="<?php echo e($user->name); ?>">
                        </div>
                        <div class="form-group">
                            <label>Tên Thường Gọi</label>
                            <input type="text" class="input-text" name="alias" value="<?php echo e($user->alias); ?>">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="input-text" name="email" value="<?php echo e($user->email); ?>" disabled="true"> 
                        </div>
                        <div class="form-group">
                            <label>Số Điện Thoại</label>
                            <input type="text" class="input-text" name="phone" value="<?php echo e($user->phone); ?>">
                        </div>
                        <div class="form-group">
                            <label>Địa Chỉ </label>
                            <input type="text" class="input-text" name="address" value="<?php echo e($user->address); ?>">
                        </div>
                        <div class="form-group">
                            <label>Cơ Bản Về Bạn</label>
                            <textarea class="input-text" name="aboutme"  > <?php echo e($user->aboutme); ?> </textarea>
                        </div>
                        <button type="submit" value="Lưu Thay Đổi" class="btn button-md button-theme"> Lưu Thay Đổi </button>
                    </form>
                </div>
                <!-- My address end -->
            </div>
        </div>
    </div>
</div>
<!-- My profile end -->
<?php echo $__env->make('client.block.brands', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>