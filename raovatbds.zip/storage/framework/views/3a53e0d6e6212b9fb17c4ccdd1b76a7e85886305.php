<?php $__env->startSection('title',$data_search  ); ?>
<?php $__env->startSection('content'); ?>
<!-- Banner start -->
<div class="blog-banner">
    <div class="container">
        <div class="breadcrumb-area">
            <h1>Tìm Kiếm Blog </h1>
            <ul class="breadcrumbs">
                <li><a href="<?php echo e(route('gethome')); ?>">Trang Chủ </a></li>
            <li class="active"><?php echo e($data_search); ?></li>
            </ul>
        </div>
    </div>
</div>
<!-- Banner end -->

<!-- Blog body start -->
<div class="blog-body content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12">
                <div class="row">
                    <?php if(count($result_search) > 0): ?>
                    <div class="main-title-2">
                        <h4>
                            <span>
                                Khoảng <?php echo count($result_search); ?> Tin Được Tìm Thấy Với Từ Khóa : <span style="color:#95c41f"> <?php echo e($data_search); ?> </span>
                            </span>
                        </h4>
                        <!-- Option bar end -->
                    </div>
                    <?php endif; ?>
                    <?php if(count($result_search) > 0): ?>
                        <?php $__currentLoopData = $result_search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iteam_blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-6 col-md-6 col-sm-6 ">
                                <div class="thumbnail blog-box-2 clearfix">
                                    <div class="blog-photo">
                                        <img src="<?php echo asset('public/admin/dist/img/'.$iteam_blog->images); ?>" alt="blog-1" class="img-responsive">
                                    </div>
                                    <!-- Detail -->
                                    <div class="caption detail">
                                        <h4><a href="<?php echo URL::route('getblog.detail',$iteam_blog['id']); ?>"><?php echo $iteam_blog->title; ?></a></h4>
                                        <!-- paragraph -->
                                        <p><?php echo $iteam_blog->tomtat; ?></p>
                                        <div class="clearfix"></div>
                                        <!-- Btn -->
                                        <a href="<?php echo URL::route('getblog.detail',$iteam_blog['id']); ?>" class="read-more">Xem Chi Tiết </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-xs-12">
                                <!-- Error404 content start -->
                                <h1>Not Found</h1>
                                <h2>Không Tìm Thấy Kết Quả  Với Từ Khóa "<?php echo $data_search; ?> "</h2>
                                <p> Hãy thử các từ khóa khác nhau hoặc xóa bộ lọc tìm kiếm</p>
                                <a href="<?php echo route('gethome'); ?>">
                                <button type="submit" class="button-sm out-line-btn">Quay Lại Trang Chủ</button>
                                </a>
                                <!-- Error404 content end -->
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                <!-- Blog box end -->

                <!-- Page navigation start 
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <li>
                            <a href="#" aria-label="Previous">
                                <span aria-hidden="true">«</span>
                            </a>
                        </li>
                        <li class="active"><a href="blog-columns-2col.html">1 <span class="sr-only">(current)</span></a></li>
                        <li><a href="blog-columns-3col.html">2</a></li>
                        <li><a href="blog-columns-3col.html">3</a></li>
                        <li>
                            <a href="blog-columns-3col.html" aria-label="Next">
                                <span aria-hidden="true">»</span>
                            </a>
                        </li>
                    </ul>
                </nav>
                Page navigation end -->
            </div>
            <!-- sidebar right start -->
            <?php echo $__env->make('client.block.sidebar_blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- sidebar right end -->
        </div>
    </div>
</div>
<!-- Blog body end -->
<?php echo $__env->make('client.block.brands', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>