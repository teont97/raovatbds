
        <?php $__currentLoopData = $data_cmtblog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iteam_cmt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
            <div class="comment">
                <div class="comment-author">
                    <a href="#">
                    <img src="<?php echo asset('public\client\img\avatar/'.Auth::user()->avatar); ?>" alt="avatar-5">
                    </a>
                </div>
                <div class="comment-content">
                    <div class="comment-meta">
                        <div class="comment-meta-author">
                            <?php echo e(Auth::user()->name); ?>

                        </div>
                        
                        <div class="comment-meta-reply">
                            <a href="javascript:void(0)"  cid="<?php echo e($iteam_cmt->id); ?>"  token="<?php echo e(csrf_token()); ?>" class="reply">Reply</a>
                        </div>
                        <div class="comment-meta-date">
                        <span class="hidden-xs"><?php echo e($iteam_cmt->created_at); ?></span>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                    <div class="comment-body">
                        <input type="hidden" id="datalog" value="<?php echo e($iteam_cmt->id); ?>">
                        <div class="comment-rating">
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star"></i>
                            <i class="fa fa-star-o"></i>
                        </div>
                        <p><?php echo $iteam_cmt->content; ?></p>
                    </div>
                </div>
            </div>
            <ul>
             
                <li class="iteam-reply<?php echo e($iteam_cmt->id); ?>">
                            <?php $__currentLoopData = $iteam_cmt->repliesblog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iteam_rep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comment">
                                <div class="comment-author">
                                    <a href="#">
                                        <img src="<?php echo asset('public\client\img\avatar/'.Auth::user()->avatar); ?>" alt="avatar-5">
                                    </a>
                                    
                                </div>
                    
                                <div class="comment-content">
                                    <div class="comment-meta">
                                        <div class="comment-meta-author">
                                           <?php echo e(Auth::user()->name); ?>

                                        </div>
                                        
                                        
                    
                                        <div class="comment-meta-date">
                                            <span class="hidden-xs"><?php echo e($iteam_rep->created_at); ?></span>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="comment-body">
                                        <div class="comment-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-half-o"></i>
                                            <i class="fa fa-star-o"></i>
                                        </div>
                                        <p style="word-wrap: break-word;"><?php echo e($iteam_rep->reply); ?></p>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </li>
           
            </ul>
            <div class="reply-form reply-form<?php echo e($iteam_cmt->id); ?> " style="display:none">
                <form method="post" id="sub-menu<?php echo e($iteam_cmt->id); ?>" >
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">    
                    <input type="hidden" id="comment_id"  name="comment_id" value="<?php echo e($iteam_cmt->id); ?>">
                    <input type="hidden" name="name" value="<?php echo e($iteam_cmt->id); ?>">
                <div class="form-group"><textarea class="form-control" id="mesreply<?php echo e($iteam_cmt->id); ?>" name="mesreply" placeholder="nhap vao day" > </textarea> </div>
                    <div class="form-group"> <input class="btn btn-primary sub-btn" catalog="<?php echo e($iteam_cmt->id); ?>"  type="button" value="Gửi"> </div>
                </form>
                    
            </div>
        </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<script>
        function checkuser(){
            var id_user = $('#id_user').val(); 
            if(id_user==0){
                $('.reply').css('display','none');
            }
            else {
                $('.reply').css('display','block');
            }
        }
        checkuser();
        $('.reply').click(function(){
            var cid = $(this).attr("cid");
            //console.log(cid)
            $('.reply-form'+cid).toggle();
            $('.reply-form'+cid).focus();
        });

        $('.sub-btn').click(function (e) {
        e.preventDefault();
        // 1 dong cmt id thi no lay caui id dau tien phai  chắc vậy đó bác . bác 
        // debug em nhìn thấy chỗ sai rồi
        
      //  var comment_id = $(this).closest("form").find('input#comment_id').val();
        var comment_id =$(this).closest("form").find('input#comment_id').val();

        //var mesreply = $('#mesreply'+comment_id).val();
        var mesreply = $('#mesreply'+comment_id).val(); 
        //console.log(comment_id); 
        //return false;
        
        $.ajax({
            type: "POST",
            url: '<?php echo e(url("/reply-blog")); ?>',
            dataType: 'JSON',
            data: {comment_id: comment_id, mesreply: mesreply},
            success: function(data) {
                if(data.error != '')
            {   
                $('#sub-menu'+comment_id)[0].reset();
                $(".iteam-reply"+comment_id).empty();
                load_repcmt(comment_id);
                console.log(data);
            }
        },
        error: function (xhr, textStatus, thrownError) {
                console.log(xhr.status);
                console.log(xhr.statusText);
                console.log(textStatus);
                console.log(thrownError);
         }
        });
    
    });
    //getcmtpost.blade.php load_repcmt();
function load_repcmt(id_cmt)
    { 
        //var cid = $(this).attr("comment_id");
        //console.log(cid);
       // return false;
        $.get("../ajax/reply-blog/"+id_cmt, function(data){
            //muon k bi lap phai empty truoc khi append 
			$(".iteam-reply"+id_cmt).append(data);
    });
}

</script>