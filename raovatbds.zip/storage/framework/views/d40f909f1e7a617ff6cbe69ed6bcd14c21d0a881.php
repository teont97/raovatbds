<?php $__env->startSection('title','Hỏi Đáp'); ?>
<?php $__env->startSection('content'); ?>
<!-- Sub banner start -->
<div class="sub-banner overview-bgi">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <h1>Faq</h1>
                <ul class="breadcrumbs">
                    <li><a href="index.html">Home</a></li>
                    <li class="active">Faq</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- Faq body start -->
<div class="faq-body content-area">
    <div class="container">
        <!-- Main title -->
        <div class="main-title">
            <h1>Các Câu Hỏi Thường Gặp</h1>
        </div>
        <div class="row">
            <div class="col-md-8 col-sm-12 col-xm-12">
                <!-- Panel box start -->
                <div class="panel-box">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#generalInformataion" data-toggle="tab" aria-expanded="true">Thông Tin Chung</a></li>
                    </ul>
                    <div class="panel with-nav-tabs panel-default">
                        <div class="panel-body">
                            <div class="tab-content">
                                <div class="tab-pane fade active in" id="generalInformataion">
                                    <div class="panel-div">
                                        <?php $__currentLoopData = $data_faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iteam_faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="panel-group" role="tablist">
                                                <div class="panel panel-default">
                                                    <div class="panel-heading active" role="tab" id="heading1">
                                                        <h4 class="panel-title">
                                                            <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse1" aria-expanded="false">
                                                                <i class="fa"></i><?php echo e($iteam_faq->title); ?>

                                                            </a>
                                                        </h4>
                                                    </div>
                                                    <div id="collapse1" class="panel-collapse collapse" role="tabpanel" aria-expanded="false">
                                                        <div class="panel-body panel-body-2">
                                                            <p> <?php echo e($iteam_faq->content); ?> </p>
                                                            <span>Câu trả lời này có hữu ích không?
                                                                <a href="#" class="yes">Đồng Ý <i class="fa fa-thumbs-o-up"></i></a>
                                                                <a href="#" class="no">Không  <i class="fa fa-thumbs-o-down"></i></a>
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Panel box end -->
            </div>
             <!-- Panel box end -->
            <?php echo $__env->make('client.block.sidebar_blog', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>;
            <!-- Panel box end -->
            
        </div>
    </div>
</div>
<!-- Faq body end -->

<!-- Intro section -->
<div class="intro-section">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-3 col-xs-12">
                <img src="img/logos/logo-2.png" alt="logo-2">
            </div>
            <div class="col-md-7 col-sm-6 col-xs-12">
                <h3>Looking To Sell Or Rent Your Property?</h3>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-12">
                <a href="submit-property.html" class="btn button-md button-theme">Submit Now</a>
            </div>
        </div>
    </div>
</div>
<!-- Intro end -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>