<?php $__env->startSection('title','Thay đổi mật khẩu '); ?>
<?php $__env->startSection('content'); ?>
<!-- Sub banner start -->
<div class="sub-banner overview-bgi">
    <div class="overlay">
        <div class="container">
            <div class="breadcrumb-area">
                <h1>Change Password</h1>
                <ul class="breadcrumbs">
                    <li><a href="index.html">Home</a></li>
                    <li class="active">Change Password</li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!-- Sub Banner end -->

<!-- Change password start -->
<div class="content-area change-password">
    <div class="container">
        <div class="row">
        <?php echo $__env->make('client.block.account', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <div class="col-lg-8 col-md-8 col-sm-7">
                    <?php if(session('mesage')): ?>
		            <p class="alert alert-warning">
			            <?php echo session('mesage'); ?>

		             </p>
                    <?php endif; ?>      
                <!-- My address start -->
                <div class="my-address">
                    <div class="main-title-2">
                        <h1><span>Thay Đổi </span> Mật Khẩu</h1>
                    </div>
                <form action="<?php echo e(route('personal.post.changepassword',Auth::user()->id)); ?>" method="POST">
                    <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                        <div class="form-group">
                            <label>Mật Khẩu Cũ</label>
                            <input type="password" class="input-text" name="current" >
                        </div>
                        <div class="form-group">
                            <label>Mật Khẩu Mới </label>
                            <input type="password" class="input-text" name="new" >
                        </div>
                        <div class="form-group">
                            <label>Xác Nhận Lại Mật Khẩu</label>
                            <input type="password" class="input-text" name="confirm-new-password" >
                        </div>
                        <button type="submit" class="btn button-md button-theme">Lưu Thay Đổi</button>
                    </form>
                </div>
                <!-- My address end -->
            </div>
        </div>
    </div>
</div>
<!-- Change password end -->


<?php echo $__env->make('client.block.brands', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>