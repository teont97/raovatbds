<p> <b>Địa Chỉ Email KH </b> : {{ $email }} </p>
<p> <b> Họ Tên KH </b> : {{ $hoten }} </p>
<p> <b> Số Điện Thoại KH </b> : {{ $phone }} </p>
<p> <b> Tiêu Đề  </b>: {{ $subject }} </p>
<b > Nội Dung </b> : {!!  $content !!}